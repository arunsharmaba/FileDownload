﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace FileDownloadProject
{
    class Program
    {
        static void Main(string[] args)
        {
            string sFolderPath = "";
            string sSourceFileName = null;
            string sTargetFileName = null;


            #region HttpFileDownload
            Console.WriteLine("**********************HTTP File Download********************");
            Console.Write("Source file url :");
            sSourceFileName = Console.ReadLine();

            Console.Write("Target folder path :");
            sFolderPath = Console.ReadLine();

            Console.Write("Target file name:");
            sTargetFileName = Console.ReadLine();

            UserFile oUserFile = new UserHttpFile();

            Thread oThread = new System.Threading.Thread(delegate () {
                oUserFile.FileDownload(sSourceFileName, sFolderPath, sTargetFileName, "", "");
            });
            oThread.Start();

            Console.WriteLine("Http file download started......................");

            #endregion

            #region FtpFileDownload
            Console.WriteLine("**********************FTP File Download********************");

            Console.Write("Source file path :");
            sSourceFileName = Console.ReadLine();

            Console.Write("Target folder path :");
            sFolderPath = Console.ReadLine();

            Console.Write("Target file name:");
            sTargetFileName = Console.ReadLine();

            Console.Write("UserName for ftp file download:");
            string sUserName = Console.ReadLine();

            Console.Write("Password for ftp file download:");
            string sPassword = Console.ReadLine();

            oUserFile = new UserFtpFile();

            Thread oThreadFtp = new System.Threading.Thread(delegate () {
                oUserFile.FileDownload(sSourceFileName, sFolderPath, sTargetFileName, sUserName, sPassword);
            });
            oThreadFtp.Start();

            Console.WriteLine("Ftp file download started.....................");
            #endregion
        }
    }
}
