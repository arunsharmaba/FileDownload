﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using FileDownloadProject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.IO;

namespace FileDownloadProject.Tests
{
    [TestClass()]
    public class UserHttpFileTests
    {
        string sourceUrl = "";
        string TargetFolder = "";
        string FileName = "";
        string username = "";
        string password = "";
        [TestMethod()]
        public void FileDownloadTest()
        {
             sourceUrl = "https://www.google.co.in/images/branding/googlelogo/2x/googlelogo_color_120x44dp.png";
             TargetFolder = @"F:\TestCaseFolders";
             FileName = "testcase.png";
            WebClient Client = new WebClient();
            if (!Directory.Exists(TargetFolder))
            {
                Directory.CreateDirectory(TargetFolder);
            }

            Client.DownloadFile(sourceUrl, TargetFolder + "\\" + FileName);
        }

        [TestMethod()]
        public void FileDownloadFtpTest()
        {
            sourceUrl = "ftp://ftp.dlptest.com/.ftpquota";
            TargetFolder = @"F:\FtpTestFolder";
            FileName = "ftptestfile.txt";
            username = "dlpuser@dlptest.com";
            password = "KZhfl2N53lsZM7E8";
            if (!Directory.Exists(TargetFolder))
            {
                Directory.CreateDirectory(TargetFolder);
            }

            String RemoteFtpPath = sourceUrl;
            String LocalDestinationPath = TargetFolder + "\\" + FileName;



            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(RemoteFtpPath);
            request.Method = WebRequestMethods.Ftp.DownloadFile;
            //  request.KeepAlive = true;
            // request.UsePassive = UsePassive;
            // request.UseBinary = UseBinary;

            request.Credentials = new NetworkCredential(username , password);

            FtpWebResponse response = (FtpWebResponse)request.GetResponse();

            Stream responseStream = response.GetResponseStream();
            StreamReader reader = new StreamReader(responseStream);

            using (FileStream writer = new FileStream(LocalDestinationPath, FileMode.Create))
            {

                long length = response.ContentLength;
                int bufferSize = 2048;
                int readCount;
                byte[] buffer = new byte[2048];

                readCount = responseStream.Read(buffer, 0, bufferSize);
                while (readCount > 0)
                {
                    writer.Write(buffer, 0, readCount);
                    readCount = responseStream.Read(buffer, 0, bufferSize);
                }
            }

            reader.Close();
            response.Close();
        }
    }
}